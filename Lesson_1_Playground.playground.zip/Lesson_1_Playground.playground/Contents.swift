import UIKit

//first task
let firstString: String = "First Lesson"
let firstInt: Int = 1000
let firstDouble: Double = 10.6
let firstFloat: Float = 12.7
let firstBool: Bool = true


//second task
var secondString: String = "First Lesson"
var secondInt: Int = 1000
var secondDouble: Double = 10.6
var secondFloat: Float = 12.7
var secondBool: Bool = true

print("------------   display before")
print(secondString)
print(secondInt)
print(secondDouble)
print(secondFloat)
print(secondBool)

secondString = "First task"
secondInt = 2000
secondDouble = 123.90
secondFloat = 1235.7
secondBool = false

print("------------   display after")
print(secondString)
print(secondInt)
print(secondDouble)
print(secondFloat)
print(secondBool)

//third task
//sum
var sumString: String = firstString + " " + secondString
var sumInt: Int = firstInt + secondInt
var sumDouble: Double = firstDouble + secondDouble
var sumFloat: Float = firstFloat + secondFloat
print("------------   sum")
print(sumString)
print(sumInt)
print(sumDouble)
print(sumFloat)

//diff
var diffInt: Int = secondInt - firstInt
var diffDouble: Double = secondDouble - firstDouble
var diffFloat: Float = secondFloat - firstFloat
print("------------   diff")
print(diffInt)
print(diffDouble)
print(diffFloat)

//mult
var multInt: Int = firstInt*secondInt
var multIntIntoDouble: Double = Double(secondInt)*firstDouble
var multDouble: Double = firstDouble*secondDouble
var multFloat: Float = firstFloat*secondFloat
print("------------   mult")
print(multInt)
print(multIntIntoDouble)
print(multDouble)
print(multFloat)

//div
var divInt: Int = secondInt/firstInt
var divIntIntoDouble: Double = Double(secondInt)/12.3
var divDouble: Double = secondDouble/firstDouble
var divFloat: Float = secondFloat/firstFloat
print("------------   div")
print(divInt)
print(divIntIntoDouble)
print(divDouble)
print(divFloat)
